# CFT-ENGINE0

A minimal placeholder project for experimenting with the CFT-ENGINE0 codebase.

## Usage

Run the engine directly to see its status message:

```bash
python engine.py
```

## Testing

This project uses pytest. Run the test suite with:

```bash
python -m pytest
```
